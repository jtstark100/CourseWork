
#----------------------------------------------
#
# Homework Assignment From: John Stark
# Course: MET CS 521
# Date: 10/1/2018
# Assignment: HW4 10.5 Page 350
#
# Print distinct numbers
#
#---------------------------------------------------
# Test Case: Enter ten numbers: 1 2 3 2 1 6 3 4 5 2
# Key: The distinct numbers are: 1 2 3 6 4 5
#---------------------------------------------------
# Reference: Course Text Page 322
inp = input ("Enter ten numbers: ")
tokens = inp.split() # Extract tokens from the string
List1 = [eval(x) for x in tokens] # Convert tokens to numbers
length = len(List1)
print ( List1 )
print ( length )
#exit ()
#-------------------------------------------------------
# Create a new list, with only distinct numbers
#
# The following sequence of code will create a list 
# of distinct numbers by putting the keyboard inputs
# into a set.  The set creation will drop duplicates.
# With sets, order and frequency do not matter
#-------------------------------------------------------
Set1 = set ( List1 )
#for j in range (0, length+1):
#	Set1.add = List1[j] # Duplicates are dropped
print ("The distinct numbers are: ", Set1)




