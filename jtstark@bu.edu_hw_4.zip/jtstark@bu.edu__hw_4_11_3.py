
#----------------------------------------------
#
# Homework Assignment From: John Stark
# Course: MET CS 521
# Date: 10/1/2018
# Assignment: HW4 11.3 Page 382
#
# Sort students by grades, rewrite 
# Listing 11.3 (Page 367)
#
# Display the student in increasing order of
# the number of correct answers
#
#----------------------------------------------
# Students answers to the questions
answers = [
	['A', 'B', 'A', 'C', 'C', 'D', 'E', 'E', 'A', 'D'],
	['D', 'B', 'A', 'B', 'C', 'A', 'E', 'E', 'A', 'D'],
	['E', 'D', 'D', 'A', 'C', 'B', 'E', 'E', 'A', 'D'],
	['C', 'B', 'A', 'E', 'D', 'C', 'E', 'E', 'A', 'D'],
	['A', 'B', 'D', 'C', 'C', 'D', 'E', 'E', 'A', 'D'],
	['B', 'B', 'E', 'C', 'C', 'D', 'E', 'E', 'A', 'D'],
	['B', 'B', 'A', 'C', 'C', 'D', 'E', 'E', 'A', 'D'],
	['E', 'B', 'E', 'C', 'C', 'D', 'E', 'E', 'A', 'D']]

# Key to the questions
keys = ['D', 'B', 'D', 'C', 'C', 'D', 'A', 'E', 'A', 'D']
# Grade all answers
List1 = []
for i in range(0, 8):
	List1.append([])    # Add an empty new row	
	# Grade one student
	correctCount = 0
	for j in range (0, 10):
		if (answers[i][j] == keys[j]):
			correctCount = correctCount + 1
	print ("Student", i, " 's correct count is", correctCount)
	List1[i] = correctCount
# List1.sort()
print ( List1 )


