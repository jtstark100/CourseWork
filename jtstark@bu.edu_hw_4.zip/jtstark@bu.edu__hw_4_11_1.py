
#----------------------------------------------
#
# Homework Assignment From: John Stark
# Course: MET CS 521
# Date: 10/1/2018
# Assignment: HW4 11.1 Page 381
#
# Sum elements column by column
#
#----------------------------------------------
# Test Case:
# 1.5 2 3 4
# 5.5 6 7 8
# 9.5 1 3 1
#
# Result[]:
# 16.5 9 13 13
#
#----------------------------------------------
# Row by row gathering of the 12 inputs
#----------------------------------------------

for i in range (0, 3):
	# Reference: Course Text Page 322
	inp = input ("Enter a 3-by-4 matrix row for row ")
	tokens = inp.split() # Extract tokens from the string
	List1 = [eval(x) for x in tokens] # Convert tokens to numbers

length = len(List1)
print ( List1 )
print ( length )
#exit ()

# Display the Test Cases:
#
for i in range (0, 4): # Rows
	for m in range (0, 5): # Columns
		print (acc[i][m])	

sum = []
# Clear the sums:
#
print ("Clear the sums")
for i in range (0, 5): # Columns
	sum[i] = 0

# Calculate out the column sums:
#
print ("Calculate out the column sums")
for i in range (0, 4): # Rows
	for m in range (0, 5): # Columns
		sum[m] = sum[m] + acc[i][m]

# Display the Column Sums:
#
print ("Display the Column Sums")
for m in range (0, 5): # Columns
	print (sum[m])





