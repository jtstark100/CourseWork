
#----------------------------------------------
#
# Homework Assignment From: John Stark
# Course: MET CS 521
# Date: 10/1/2018
# Assignment: HW4 10.1 Page 349
#
# Read a list of scores and assign Grades
#
#----------------------------------------------
# Test Case: Enter Scores: 40 55 70 58
# Key: CBAB
#----------------------------------------------
# Reference: Course Text Page 322
inp = input ("Enter Scores with spaces: ")
tokens = inp.split() # Extract tokens from the string
List1 = [eval(x) for x in tokens] # Convert tokens to numbers
print ( List1 )
#exit ()
for i in range (0, 4):
	score = List1[i]
	grade = 'F'
	if ( score >= 70 ): grade = 'A'
	elif ( score >= 60 ): grade = 'B'
	elif ( score >= 50 ): grade = 'C'
	elif ( score >= 40 ): grade = 'D'
	print ("Student", "score is", "and grade is ", grade)




