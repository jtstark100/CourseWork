
#----------------------------------------------
#
# Homework Assignment From: John Stark
# Course: MET CS 521
# Date: 10/1/2018
# Assignment: HW4 14.1 Page 495
# Display Keywords
# Revise listing 14.4 CountKeywords.py (487)
#
# NOTE:
#
# Simulated Python file input is being used below.
# This is because while attemping to read in the file
# with Spyder 3 there were various errors occuring that
# seem to be related to the module installations and Unicode.
# The most recent error is:
#
#  File "C:/Users/John/.spyder-py3/temp.py", line 16
#    filename="C:\Users\John\Desktop\abc.py"
#            ^
# SyntaxError: (unicode error) 'unicodeescape' codec
# can't decode bytes in position 2-3: truncated \UXXXXXXXX escape
#
#----------------------------------------------
#import os.path
#import sys
#-------------------------------------------------------------------
# Create Dictionary/Associative Array of stats for each kw
# kwstat[][]
#-------------------------------------------------------------------
keyWords = {"and", "as", "assert", "break", "class",
			"continue", "def", "del", "elif", "else",
			"except", "False", "finally", "for", "from",
			"global", "if", "import", "in", "is", "lambda",
			"None", "nonlocal", "not", "or", "pass", "raise",
			"return", "True", "try", "while", "with", "yield"}
#-------------------------------------------------------------------
kwstat = {} # Create an empty dictionary
for i in set ( keyWords ):
	kwstat[i] = 0
print (kwstat)
#-------------------------------------------------------------------
#file = input("Enter a Python source code file: ").strip()
#if not os.path.isfile(filename): # Check if file exists
#	print("File", filename, "does not exist")
#	sys.exit()
#filename="C:\Users\John\Desktop\abc.py"
#infile = open(filename, "r") # Open files for read/input
#text = infile.read().split() # Read and split words from the file
#-------------------------------------------------------------------
# Simulated Python File input:
text = "break continue elif break for".split()
count = 0
print ( text )
for word in text:
	print ( word )
	if word in keyWords:
		count +=1
		# Add to new or pre-existing kwstat
		kwstat[word] = kwstat[word] + 1

print("The number of keywords is: ", count)
#print("The number of keywords in", filename, "is", count)
#Display the keywords and their counts:
print (kwstat)






