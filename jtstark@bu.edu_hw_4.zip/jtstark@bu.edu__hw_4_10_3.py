
#----------------------------------------------
#
# Homework Assignment From: John Stark
# Course: MET CS 521
# Date: 10/1/2018
# Assignment: HW4 10.3 Page 349
#
# Read a list of integers and count how many
# of each
#
#----------------------------------------------
# Test Case: Enter integers between 1 and 100:
# Key: 2 5 6 5 4 3 23 43 2
#----------------------------------------------
# Reference: Course Text Page 322
inp = input ("Enter Variable length list of integers: ")
tokens = inp.split() # Extract tokens from the string
List1 = [eval(x) for x in tokens] # Convert tokens to numbers
length = len(List1)
print ( List1 )
print ( length )
#exit ()
#-------------------------------------------------------
# The following sequence of code creates a dictionary
# where the keys are 0-100, and the values are
# the number of occurences coming from the keyboard
#-------------------------------------------------------
numdict = {} # Create an empty dictionary
for i in range (0, 101):
	numdict[i] = 0

print (numdict)
#exit ()
# Calculate out the dictionary values
for i in range ( 0, length ):
	j = List1[i]
	numdict[j] = numdict[j] + 1
# print out the dictionary
for i in range (1, 101):
	print (i, " occurs ", numdict[i], " times")




