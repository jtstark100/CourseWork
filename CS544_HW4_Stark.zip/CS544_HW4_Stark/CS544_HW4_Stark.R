#***********************************************************
# Refer to running code w/ plots: CS544_HW4_Stark.R
# Refer to Plots/Answers: CS544_HW4_Stark_PLOTS_ANSWERS.doc
#***********************************************************
#
# John Stark
# MET CS 544 - R Foundations
# November 18, 2019
#
# Homework 4
#
#***********************************************************

#*********************************************
# Part 1 Binomial Distribution
#*********************************************
# Reference: YT: Organic Chem Tutor: 
#                    YT: Bernoulli & Binomial Random Variables
#*********************************************
#---------------------------------------------------------------
# Part 1a) Compute and plot the probability distribution for 
# scoring a perfect score over the next five attempts.
#---------------------------------------------------------------
# Part 1b) Plot the Cumulative Distribution for the above
# Refer to plots: CS544_HW4_Stark.R
#---------------------------------------------------------------
ptotal = sum (dbinom (0:5, size=5, prob=0.5))
ptotal
x = c (0,1,2,3,4,5)
# PDF
dvect = dbinom (0:5, size=5, prob=0.5)
dvect
# CDF
pvect = pbinom (0:5, size=5, prob=0.5)
pvect
# 2 figures arranged in 1 row and 2 columns
attach(mtcars)
par(mfrow=c(1,2))
# Run Plots
PDF <- dvect
plot (0:5, PDF)
#
CDF<- pvect
plot (0:5, CDF)
#---------------------------------------------------------------
#---------------------------------------------------------------
#Part 1c) Repeat a) and b) if the student has 75% 
# chance of scoring a perfect score.
# Refer to plots: CS544_HW4_Stark.R
#---------------------------------------------------------------
ptotal = sum (dbinom (0:5, size=5, prob=0.75))
ptotal
x = c (0,1,2,3,4,5)
# PDF
dvect = dbinom (0:5, size=5, prob=0.75)
dvect
# CDF
pvect = pbinom (0:5, size=5, prob=0.75)
pvect
# 2 figures arranged in 1 row and 2 columns
attach(mtcars)
par(mfrow=c(1,2))
# Run Plots
PDF <- dvect
plot (0:5, PDF)
#
CDF<- pvect
plot (0:5, CDF)
#---------------------------------------------------------------
#---------------------------------------------------------------
# d) Repeate a) and b) if the student has a 35% chance of scoring a perfect score.
# Refer to plots: CS544_HW4_Stark.R
#---------------------------------------------------------------
ptotal = sum (dbinom (0:5, size=5, prob=0.35))
ptotal
x = c (0,1,2,3,4,5)
# PDF
dvect = dbinom (0:5, size=5, prob=0.35)
dvect
# 2 figures arranged in 1 row and 2 columns
attach(mtcars)
par(mfrow=c(1,2))
# CDF
pvect = pbinom (0:5, size=5, prob=0.35)
pvect
# Run Plots
PDF <- dvect
plot (0:5, PDF)
#
CDF<- pvect
plot (0:5, CDF)
#---------------------------------------------------------------
#---------------------------------------------------------------
#*********************************************
# Part 2 Binomial Distribution
#*********************************************
#---------------------------------------------------------------
# Part 2a) What is the probability that four flights will arrive on time in the next
# next 10 flights?
#---------------------------------------------------------------
ptotal = sum (dbinom (0:9, size=10, prob=0.8))
ptotal
x = c (0,1,2,3,4,5,6,7,8,9)
# PDF
dvect = dbinom (0:9, size=10, prob=0.8)
dvect
# CDF
pvect = pbinom (0:9, size=10, prob=0.8)
pvect
# 2 figures arranged in 1 row and 2 columns
attach(mtcars)
par(mfrow=c(1,2))
# Run Plots
PDF <- dvect
plot (0:9, PDF)
#
CDF<- pvect
plot (0:9, CDF)
#---------------------------------------------------------------
#---------------------------------------------------------------
# Part 2b) What is the probability that four or fewer
# flights will arrive on time in the next 10 flights?
#---------------------------------------------------------------
ptotal = sum (dbinom (0:9, size=10, prob=0.4))
ptotal
x = c (0,1,2,3,4,5,6,7,8,9)
# PDF
dvect = dbinom (0:9, size=10, prob=0.4)
dvect
# CDF
pvect = pbinom (0:9, size=10, prob=0.4)
pvect
# 2 figures arranged in 1 row and 2 columns
attach(mtcars)
par(mfrow=c(1,2))
# Run Plots
PDF <- dvect
plot (0:9, PDF)
#
CDF<- pvect
plot (0:9, CDF)
#---------------------------------------------------------------
#---------------------------------------------------------------
# Part 2c) Compute the probability distribution for
# the next 10 flights.
#
# Part 2d) Show the Probabiltiy Mass Function (PDF)
# and the Cumulative Distribution Function
# for the next 10 flights.
#---------------------------------------------------------------
ptotal = sum (dbinom (0:9, size=10, prob=0.4))
ptotal
x = c (0,1,2,3,4,5,6,7,8,9)
# PDF
dvect = dbinom (0:9, size=10, prob=0.4)
dvect
# CDF
pvect = pbinom (0:9, size=10, prob=0.4)
pvect
# 2 figures arranged in 1 row and 2 columns
attach(mtcars)
par(mfrow=c(1,2))
# Run Plots
PDF <- dvect
plot (0:9, PDF)
#
CDF<- pvect
plot (0:9, CDF)
#---------------------------------------------------------------
#*********************************************
# Part 3 Poisson Distribution
#*********************************************
#---------------------------------------------------------------
# Part 3a) P(serving exactly 3 cars) =
#---------------------------------------------------------------
# lambda = mean = 10/60 = 0.666 cars/minute
dp = dpois (x=3, lambda=0.666)
dp
#---------------------------------------------------------------
# Part 3b) P(serving at least 3 cars) =
#---------------------------------------------------------------
dp = sum (dpois (0:3, lambda=0.666))
dp
x = c (0,1,2,3)
# PDF
dvect = dpois (0:3, lambda=0.666)
dvect
# 2 figures arranged in 1 row and 2 columns
attach(mtcars)
par(mfrow=c(1,2))
# CDF
pvect = ppois (0:3, lambda=0.666)
pvect
# Run Plots
PDF <- dvect
plot (0:3, PDF)
#
CDF<- pvect
plot (0:3, CDF)
#---------------------------------------------------------------
#---------------------------------------------------------------
# Part 3c) P(serving between 2 and 5 
# cars(inclusive)) =
#---------------------------------------------------------------
dp5 = dpois (x=5, lambda=0.666)
dp5
dp2 = dpois (x=2, lambda=0.666)
dp2
# P( 2 <= x <= 5) = P(5) - P(2) = 
dp52 = dp5 - dp2
dp52
#---------------------------------------------------------------
#---------------------------------------------------------------
# Part 3d) Calculate and plot the Probability Mass
# Function for the first 20 cars
# Refer to plots: CS544_HW4_Stark.R
#---------------------------------------------------------------
# PDF
dvect = dpois (0:19, lambda=0.666)
dvect
# CDF
pvect = ppois (0:19, lambda=0.666)
pvect
# 2 figures arranged in 1 row and 2 columns
attach(mtcars)
par(mfrow=c(1,2))
# Run Plots
PDF <- dvect
plot (0:19, PDF)
#
CDF<- pvect
plot (0:19, CDF)
#---------------------------------------------------------------
#---------------------------------------------------------------
#*********************************************
# Part 4 Discrete Uniform Distribution
#*********************************************
# Reference: YT: ukmathsteacher: 
# Discrete Uniform Distribution
# YT: Uniform Dist using R Studio: KA Jager
#*********************************************
# Suppose your exams are graded using a uniform
# distribution between
#70 and 90.
#---------------------------------------------------------------
# Part 4a) What are the probabilities of 70, 80, 100?
#---------------------------------------------------------------
# P(70) = 1/10
# P(80) = 1/10
# P(100) = 0
#---------------------------------------------------------------
# Part 4b) What is the mean and stdev of this distribution?
  mean = (70+80+90)/3=240/3=80
  stddev = sqrt((70-80)**2 + 0 + (90-80)**2)=sqrt(200)=14.142
  #---------------------------------------------------------------
 # c) P (X <= 80) = P(70) + P(80) = 2/10
  
 #  d) P( X > 80 ) = P(80) + (P90)
  
  # e) P( 80 <= X < = 90) = P(90) - P(80)
  #---------------------------------------------------------------
  range = seq (70,90,.01)
  dun=dunif(range, 70, 90)
  plot (range, dun, type='l', ylim=c(0,max(dun)+0.01))
  pun = punif(range, 70, 90)
  # 2 figures arranged in 1 row and 2 columns
  attach(mtcars)
  par(mfrow=c(1,2))
  plot (range, dun, type='l', ylim=c(0,max(dun)+0.01))
  plot (range, pun, type='l', ylim=c(0,max(pun)+0.01))
  #---------------------------------------------------------------
  #*********************************************
  # Part 5 Normal Distribution
  #*********************************************
  # Reference: YT: Organic Chem Tutor: 
  # Normal Distribution and Probability
  # YT: Marin Lecture: Normal Distribution
  #*********************************************
#  Suppose that visitors at a theme park spend an average of $100 on 
#  souvenirs.  Assume that the money spent is normally distributed with 
#  a standard deviation of $10.
  
  mean = 100
  stddev = 10
  z = (x-mean)/stddev
  #---------------------------------------------------------------
  # Plot the non-standard Normal Curve
  #---------------------------------------------------------------
  DollarsSpent <- seq (from=55, to=130, by=1)
  DollarsSpent
  NDist <- dnorm (DollarsSpent, mean=100, sd=10)
  plot (DollarsSpent, NDist)
  #---------------------------------------------------------------
  #---------------------------------------------------------------
  z1 = (80-mean)/stddev = -20/10 = -2
  z2 = (90-mean)/stddev = -10/10 = -1
  #---------------------------------------------------------------
#  a) Show the Probability Distribution Function of this distribution
# the three standard deviations on either side of the mean.
#---------------------------------------------------------------
# b) What is the probability that a randomly selected visitor will spend more
# than $120?
  #---------------------------------------------------------------
# z = (120-100)/10 = 20/10 = 2
# Area =0.97725
# (Leftmost)
# P(x>120) = 1-P(2)=1-0.97725=.02275=>2.275%
#---------------------------------------------------------------
# c) What is the probability that a randomly selected visitor will spend between
# $80 and $90 (inclusive)?
  #---------------------------------------------------------------
# z = (80-100)/10 = 20/10 = -2
# Area = 0.02275
# (Leftmost)
# z = (90-100)/10 = 20/10 = -1
# Area = .15866
# (Leftmost)
# P(80 <= X <= 90) = .15866 - 0.02275 = 0.13591=>13.59%
#---------------------------------------------------------------
# d) What are the probabilities of spending within one standard deviation, two
# standard deviations, and three standard deviations, respectively?
  #---------------------------------------------------------------
# 68%, 94.45%, 99.73%
#---------------------------------------------------------------
# e) Betweeen what two values will the middle 90% of the money spent will fall?
#  It's close to 94.45% as shown for 2 standard deviations in part d above.
#---------------------------------------------------------------
# f) If the theme park gives a free T-Shirt for the top 5% of the spenders,
# what will be the minimum amount you have to spend to get the free
# T-Shirt?
#---------------------------------------------------------------
# The top 5% of the spenders will correspond to leaving 95% of the
# area under the Standard Normal. Using the Standard Normal Table,
# 95% corresponds to a z value of 1.64.  Solving for x and substituting:
# z = (x-a)/sigma
# z(sigma) = x - a
# z(sigma) + a = x
# 10z + 100 = x
# 16.4 + 100 = 116.4 = x
# You have to spend $116.40 to get the T-Shirt.
#---------------------------------------------------------------
# g) Show a plot for 10,000 visitors using the above distribution.
# Refer to plots: CS544_HW4_Stark.R
#---------------------------------------------------------------
#---------------------------------------------------------------
# Plot the non-standard Normal Curve, scaled by 10k
#---------------------------------------------------------------
Dollars <- seq (from=55, to=130, by=1)
Dollars
Dollars10k = Dollars * 10000
NDist <- dnorm (Dollars, mean=100, sd=10)
plot (Dollars10k, NDist)
#---------------------------------------------------------------
#*********************************************
# Part 6 Exponential Distribution
#*********************************************
# Reference: YT: Organic Chem Tutor: 
# Probability Exponential Distribution Problems
#*********************************************
# Suppose your cell phone provider's customer support
# receives calls at the rate of of 18 per hour.

# mean = 18 calls/hour = 0.3 calls/minute
# PDF: f(x) = (mean)exp(-(mean)x)

# Part 6a) P(X <  2 minutes) = 1 - exp ( -(lambda)x ) 
# = 1 - exp(-6.666) 
# = 1 - 1/exp(0.6)
# = 1 - 0.006
# = 0.49
# (Leftmost)

# Part 6b) P(X  < 5 minutes) = 1 - exp ( -(lambda)x ) 
# = 1 - exp(-16.666) 
# = 1 - 1/exp(1.5)
# = 0.5
#(Rightmost)

# c) P(2 <= X <= 5) = P(5) - P(2) =  0.50 - 0.49 = 0.01
#---------------------------------------------------------------
# Plot 6d) Show the Cumulative Distribution Function 
#---------------------------------------------------------------

