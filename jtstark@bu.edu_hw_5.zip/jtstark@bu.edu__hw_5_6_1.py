
#----------------------------------------------
#
# Homework Assignment From: John Stark
# Course: MET CS 521
# Date: 10/7/2018
# Assignment: HW5 6.1 Page 203
#
# Pentagonal Numbers
#
#----------------------------------------------
# Test Case: n = 1 to 100
#----------------------------------------------
def getPentagonalNumber( n ):
	result = 3 * ( 3*n - 1) / 2
	return (result)

List1 = []
# Print 100 Pentagonal Numbers with ten on each line
for n in range (1, 100):
	pNumber = getPentagonalNumber( n )
	List1.append( pNumber )
print ( List1 )
print ( "\n\n")

a = 0
b = 10
c = 0
d = 10
for j in range (a,b):
	for i in range (c,d): 
		print ( " ", List1[i], end="" )
print ( "\n" )
a = a + 10
b = b + 10
c = c + 10
d = d + 10




		