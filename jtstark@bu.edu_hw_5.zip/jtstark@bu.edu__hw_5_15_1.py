
#----------------------------------------------
#
# Homework Assignment From: John Stark
# Course: MET CS 521
# Date: 10/7/2018
# Assignment: HW5 15.1 Page 523
#
# Sum the digits in an integer using recursion
#
#----------------------------------------------
# Test Case: 234 => Should be 9
#----------------------------------------------
def  sumDigits( n ):
	# Recursive Routine
	# n is a List index for sumDigits[]
	print ("Entry to sumDigits:n: ", n)
	#---------------------------------------------------
	#print ("Entry to sumDigits:currDigit: ", List1(n))
	# "TypeError: 'list' object is not callable "
	#---------------------------------------------------
	sumTotal = 0
	if n == 0: # BASE CASE
		return 1
	else:
		#return sumTotal + sumDigits (n-1) # RECURSIVE CALL
	return 	
# main

inp = input ( "Enter an integer: " )
List1 = list (inp)
n = len (inp) - 1
#print (n)
sumDig = sumDigits( n )
print ( "The sum of the integer's digits is: " , sumDig)







