
#----------------------------------------------
#
# Homework Assignment From: John Stark
# Course: MET CS 521
# Date: 10/7/2018
# Assignment: HW5 6.5 Page 203
#
# Sort Three Numbers
#
#----------------------------------------------
# Test Case: 3 2 1
# Result:    1 2 3
#----------------------------------------------
def displaySortedNumbers ( List ):
	print ( "The sorted numbers are: " )
	for i in range ( 0, 4 ):
		print ( List[i] )
	return


# Enter three numbers into a list
# Reference Course Text page 322
inp = input ( "Enter three integers with a space: " )
tokens = inp.split() # Extract tokens from the string
List1 = [eval(x) for x in tokens] # Convert tokens to numbers
print ( List1 )
# Sort the List of three numbers
List1.sort()
displaySortedNumbers ( List1 )


















