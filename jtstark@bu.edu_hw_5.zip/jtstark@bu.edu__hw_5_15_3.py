
#----------------------------------------------
#
# Homework Assignment From: John Stark
# Course: MET CS 521
# Date: 10/7/2018
# Assignment: HW5 15.3 Page 523
#
# Compute greatest common divisor using recursion
# Reference: Modified from Course Text page 183
#            Listing 6.5, 6.6
# Reference: The math module has a gcd function
#
#----------------------------------------------
# Test Case: 5 10  gcd = 5
# Test Case: 9 10  gcd = 1
# Test Case: 45 75 gcd = 15
#----------------------------------------------
#def  getGCD( n , m  ):
	# Recursive Routine
	#if m % n == 0: gcd = n #
	#else: gcd = getGCD (n, m % n) # Recursive CALL
	#print ( "BASE CASE: " , gcd)
	#return gcd
#from GCDFunction import gcd # Import the gcd Function
from math import gcd # Import the gcd Function
# Reference Course Text page 322
inp = input ( "Enter two integers with a space: " )
tokens = inp.split() # Extract tokens from the string
List1 = [eval(x) for x in tokens] # Convert tokens to numbers
print ( List1 )
#getGCD( List1[0] , List1[1] )
print ( "The greatest common divisor for", List1[0], "and", List1[1])
print ("is", gcd ( List1[0], List1[1] ))















