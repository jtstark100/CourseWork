
#----------------------------------------------
#
# Homework Assignment From: John Stark
# Course: MET CS 521
# Date: 10/6/2018
# Assignment: HW5 6.3
#
# Palindrome Integer
# (Reads the same backwards and forward)
#
#----------------------------------------------
# Test Case: 232
#----------------------------------------------
def isPalindrome ( l, Rl ):
	# Use the reverse function to implement isPalindrome
	print ("Entry to isPalindrome: ", l , Rl )
	diff = -1
	if ( l == Rl ):
		print ("This is a palindrome")
		diff = 0
	else:
		print ("This is not a palindrome")
		diff = 1
	print ( diff )
	return diff

# Read the word
# Reference Course Text page 322
inp = input ( "Enter three integers with a space: " )
tokens = inp.split() # Extract tokens from the string
List1 = [eval(x) for x in tokens] # Convert tokens to numbers
RList1 = list (List1)
RList1.reverse()
print ( List1 )
print ( RList1 )
# Call isPalindrome to compare the word and its reverse
isPalindrome ( List1, RList1 )





