
#----------------------------------------------
#
# Homework Assignment From: John Stark
# Course: MET CS 521
# Date: 10/7/2018
# Assignment: HW5 6.9 Page 205
#
# Conversion between feet and meters:
# foot = meter/0.305
# meter = 0.305 * foot
#
#----------------------------------------------
# Test Case: 
#----------------------------------------------
def footToMeter ( foot ):
	meter = 0.305 * foot
	return meter

def meterToFoot ( meter ):
	foot = meter/0.305
	return foot


#
#foot = eval (input ( "Enter Feet: " ))
#ftm = footToMeter ( foot )
#print ( "The Result (Meters) is: ", ftm )
#
#
#meters = eval (input ( "Enter Meters: " ))
#mtf = meterToFoot ( meters )
#print ( "The Result (Feet) is: ", mtf )
#
print ("Feet      Meters")
#
feet = 1.0
ftm = footToMeter ( feet )
print (feet, ftm)
#
feet = 2.0
ftm = footToMeter ( feet )
print (feet, ftm)
#
feet = 9.0
ftm = footToMeter ( feet )
print (feet, ftm)
#
feet = 10.0
ftm = footToMeter ( feet )
print (feet, ftm)
#
#---------------------------------
#
print ("Meters      Feet")
#
meters = 20.0
mtf = meterToFoot ( meters )
print (meters, mtf)
#
meters = 26.0
mtf = meterToFoot ( meters )
print (meters, mtf)
#
meters = 60.0
mtf = meterToFoot ( meters )
print (meters, mtf)
#
meters = 66.0
mtf = meterToFoot ( meters )
print (meters, mtf)
#












