#***********************************************************
# Refer to running code: CS544_HW5_Stark.R
# Refer to Plots: CS544_HW5_Stark_PLOTS.doc
#***********************************************************
#
# John Stark
# MET CS 544 - R Foundations
# December 3, 2019
#
# Homework 5
#
# References:
#
# 1) The Negative Binomial Distribution
#     YT: jbstatistics 12/18/2012
#
# 2) The Negative Binomial Distribution with Replacement
#     YT: Drangonfly Statistics
#
# 3) Source of MU284: http://lib.stat.cmu.edu/datasets/mu284
#
#***********************************************************
# CS544 Module 5 Assignment 
#*********************************************
# Part 1) Central Limit Theorem (20 points) 
#*********************************************
# The input data consists of the sequence from 11 to 20 (11:20). 
# Show the following three plots in a single row. 
#------------------------------------------------------------------------------------
# a) Show the histogram of the densities of this distribution.  
#------------------------------------------------------------------------------------
x <- seq (1, 10)
x
y <- seq (11, 20)
y
summary(y)
hist (y)
#------------------------------------------------------------------------------------
# b) Using all samples of this data of size 2, show the histogram
# of the densities of the sample means. 
#------------------------------------------------------------------------------------
x1 <- seq (1:10)
x1
ysamples1 <- sample (11:20, 2)
ysamples1
mean_b = mean (ysamples1)
#------------------------------------------------------------------------------------
# c) Using all samples of this data of size 5, show the histogram
#  of the densities of the sample means. 
#------------------------------------------------------------------------------------
x2 <- seq (1:10)
x2
ysamples2 <- sample (11:20, 5)
ysamples2
mean_c = mean (ysamples2)
#------------------------------------------------------------------------------------
#hist (x2, ysamples2)
#Error in hist.default(x1, ysamples1) : 
#  some 'x' not counted; maybe 'breaks' do not span range of 'x'
# > hist (x2, ysamples2)
# Error in hist.default(x2, ysamples2) : 
#  some 'x' not counted; maybe 'breaks' do not span range of 'x'
#------------------------------------------------------------------------------------
# d) Compare means and standard deviations of the above three
# distributions. 
#------------------------------------------------------------------------------------
mean1 <- mean (y)
mean1
std1 <- sd(y)
std1
mean2 <- mean (ysamples1)
mean2
std2 <- sd (ysamples1)
std2
mean3 <- mean (ysamples2)
mean3
std3 <- sd(ysamples2)
#------------------------------------------------------------------------------------
# Run Plots
#------------------------------------------------------------------------------------
# Three plots arranged in 1 row:
#
par (mfrow=c(1,3))
#------------------------------------------------------------------------------------
hist (y)
hist (x1, ysamples1)
hist (x2, ysamples2)
#------------------------------------------------------------------------------------
# > hist (y)
# > hist (x1, ysamples1)
# Error in hist.default(x1, ysamples1) : 
#  some 'x' not counted; maybe 'breaks' do not span range of 'x'
# > hist (x2, ysamples2)
# Error in hist.default(x2, ysamples2) : 
#  some 'x' not counted; maybe 'breaks' do not span range of 'x'
# > 
#------------------------------------------------------------------------------------
#********************************************* 
# Part 2) Central Limit Theorem (20 points) 
#*********************************************
# The data in the file queries.csv contains the number of queries
#  Google has had each day for a one year period (365 days). 
# The data file is also available at 
# http://kalathur.com/cs544/data/queries.csv. 
# Use this link to read the data using read.csv function when 
# submitting the homework. 
#------------------------------------------------------------------------------------
# a) Show the histogram of the distribution of the number of queries.
# Compute the mean and standard deviation of the number of 
# queries Google has had per day.   
#------------------------------------------------------------------------------------
x <- read.csv("http://kalathur.com/cs544/data/queries.csv")
x
hist(x[,1])
#
mean2a = mean ( x[,1] )
mean2a
stddev2a = sd  ( x[,1] )
stddev2a
summary ( x[,1] )
#------------------------------------------------------------------------------------
# b) Draw 1000 samples of this data of size 5, show the histogram
# of the densities of the sample means.  Compute the mean of the
# sample means and the standard deviation of the sample means. 
#------------------------------------------------------------------------------------
sample5 = sample ( x[,1], 5, replace=FALSE, prob=NULL)
sample5
#
# Densities of the sample means
hist (sample5)
#
mean5= mean (sample5)
mean5
stddev5 = sd (sample5)
stddev5
#------------------------------------------------------------------------------------
# c) Draw 1000 samples of this data of size 20, show the histogram
# of the densities of the sample means.  Compute the mean of the
# sample means and the standard deviation of the sample means.
#------------------------------------------------------------------------------------
sample20 = sample ( x[,1], 20, replace=FALSE, prob=NULL)
sample20
#------------------------------------------------------------------------------------
# Run Plots
#------------------------------------------------------------------------------------
# Three plots arranged in 1 row:
#
par (mfrow=c(3,1))
hist (sample5)
hist (sample20)
hist(x[,1])
#------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------
mean20= mean (sample20)
mean20
stddev20 = sd (sample20)
stddev20
#------------------------------------------------------------------------------------
# d) Compare of means and standard deviations of the above three
#     distributions.  
#------------------------------------------------------------------------------------
mean2a
stddev2a
#------------------------------------------------------------------------------------
mean5
stddev5
#------------------------------------------------------------------------------------
mean20
stddev20
#********************************************* 
# Part 3) Central Limit Theorem
# Negative Binomial distribution (20 points) 
#********************************************* 
# Suppose the input data follows the negative binomial distribution with the
# parameters size = 5 and prob = 0.5. 
#------------------------------------------------------------------------------------ 
# a) Generate 1000 random numbers from this distribution. Show the
# barplot with the proportions of the distinct values of this distribution. 
#------------------------------------------------------------------------------------
# Reference: Module 3 Page 36
#------------------------------------------------------------------------------------
library (MASS)
set.seed(5)
pmf3b = dnbinom ( 0:1000, size=5, prob=0.5)
summary (pmf3b)
#------------------------------------------------------------------------------------
# b) With samples sizes of 10, 20, 30, and 40, generate the data for
# 5000 samples using the same distribution. Show the histograms
# of the densities of the sample means. Use a 2 x 2 layout. 
#------------------------------------------------------------------------------------
# Reference: Module 5 Page 15
#------------------------------------------------------------------------------------
samples <- 5000
sample.size <- 10
xbar10 <- numeric(samples)
for (i in 1:samples) {
  xbar10[i] <- mean(sample(pmf3b, size=sample.size,replace=TRUE))
}
#------------------------------------------------------------------------------------
samples <- 5000
sample.size <- 20
xbar20 <- numeric(samples)
for (i in 1:samples) {
  xbar20[i] <- mean(sample(pmf3b, size=sample.size,replace=TRUE))
}
#------------------------------------------------------------------------------------
samples <- 5000
sample.size <- 30
xbar30 <- numeric(samples)
for (i in 1:samples) {
  xbar30[i] <- mean(sample(pmf3b, size=sample.size,replace=TRUE))
}
#------------------------------------------------------------------------------------
samples <- 5000
sample.size <- 40
xbar40 <- numeric(samples)
for (i in 1:samples) {
  xbar40[i] <- mean(sample(pmf3b, size=sample.size,replace=TRUE))
}
#------------------------------------------------------------------------------------
# Run Plots
#------------------------------------------------------------------------------------
# Four plots arranged (2x2):
par (mfrow=c(2,2))
#------------------------------------------------------------------------------------
hist(xbar10, prob=TRUE, breaks=15, xlim=c(0,0.6), ylim=c(0,0.6),
     main = "Sample Size =10")
#
hist(xbar20, prob=TRUE, breaks=15, xlim=c(0,0.6), ylim=c(0,0.6),
     main = "Sample Size =20")
#
hist(xbar30, prob=TRUE, breaks=15, xlim=c(0,0.6), ylim=c(0,0.6),
     main = "Sample Size =30")
#
hist(xbar40, prob=TRUE, breaks=15, xlim=c(0,0.6), ylim=c(0,0.6),
     main = "Sample Size =40")
#------------------------------------------------------------------------------------
# c) Compare of means and standard deviations of the data from
#  with the four sequences generated in b). 
#------------------------------------------------------------------------------------
mean10 = mean (xbar10)
mean10
mean20 = mean (xbar20)
mean20
mean30 = mean (xbar30)
mean30
mean40 = mean (xbar40)
mean40
#
stddev10 = sd (xbar10)
stddev10
stddev20 = sd (xbar20)
stddev20
stddev30 = sd (xbar30)
stddev30
stddev40 = sd (xbar40)
stddev40
#********************************************* 
# Part4) Sampling (40 points) 
#*********************************************
# Use the MU284 dataset from the sampling package.
# Use a sample size of 20 for each of the following. 
# Source of MU284: http://lib.stat.cmu.edu/datasets/mu284
#
library(sampling) 
data (MU284)
x <- MU284
x
mode (x)
head(x)
tail(x)
names(x)
#------------------------------------------------------------------------------------
# a) Show the sample drawn using simple random sampling without
# replacement. Show the frequencies for each region (REG)
# (geographic region indicator). 
# Show the percentages of these with respect to the entire dataset. 
#------------------------------------------------------------------------------------ 
# Sample size is given as 20
# Simple Random Sampling w/o replacement
#
# Reference: Module 5, Page 19
s4a <- srswor (14, 284)
s4a
# > s4a
# [1] 2 4 5 2 8 5 3 3 2 8 8 4 8 8 8 8 2 5 7 4
mean_samples = mean (s4a)
mean_samples
sd_samples = sd (s4a)
sd_samples
#------------------------------------------------------------------------------------
#mean_pop = mean (MU284)
#mean_pop
#sd_pop = sd (MU284)
#sd_pop
#------------------------------------------------------------------------------------
# b) Show the sample drawn using systematic sampling. 
#  Show the frequencies for each region (REG)
#  (geographic region indicator). 
#  Show the percentages of these with respect to the entire dataset. 
#------------------------------------------------------------------------------------
# Sample size is given as 20
# Systematic Sampling
#
# Reference: Module 5, Pages 24,25
N <- 284
n <- 20
# Items in each group
k <- ceiling (N / n)
k
# Random item from first group
r <- sample (k,1)
r
# Select every kth item:
s4b <- seq (r, by = k, length = 20)
s4b 
#------------------------------------------------------------------------------------
# c) Calculate the inclusion probabilities using the S82 (total number
# of seats in municipal council) variable.
# Using these values, show the sample drawn using systematic
# sampling. Show the frequencies for each region (REG) (geographic
# region indicator)
# Show the percentages of these with respect to the entire dataset. 
#------------------------------------------------------------------------------------
# Sample size is given as 20
# Systematic Sampling
#------------------------------------------------------------------------------------
# Reference: Module 5, Pages 24,25,26,27
N <- 284
n <- 20
# Items in each group
k <- ceiling (N / n)
k
# Random item from first group
r <- sample (k,1)
r
# Select every kth item:
s4c <- seq (r, by = k, length = 20)
s4c 
pik <- inclusionprobabilities(MU284$S82, 20)
length(pik)
sum(pik)
pik
#------------------------------------------------------------------------------------
# > length(pik)
# [1] 284
# > sum(pik)
# [1] 20
# > pik
#  [1] 0.07259259 0.06074074 0.06074074 0.06074074 0.09037037 0.06074074
#  [7] 0.09037037 0.09037037 0.04592593 0.09037037 0.06666667 0.06074074
#------------------------------------------------------------------------------------
hist (s4b, MU284$REG)
hist (s4b, MU284$S82)
#------------------------------------------------------------------------------------
# > hist (s4b, MU284$REG)
# Error in hist.default(s4b, MU284$REG) : 
#   some 'x' not counted; maybe 'breaks' do not span range of 'x'
# > hist (s4b, MU284$S82)
# Error in hist.default(s4b, MU284$S82) : 
#  some 'x' not counted; maybe 'breaks' do not span range of 'x'
# > 
#------------------------------------------------------------------------------------
# d) Order the data using the REG (Geographic Region Indicator)
# variable. Draw a stratified sample
# using proportional sizes based on the REG variable. 
# Show the frequencies for each region (REG). 
# Show the percentages of these with respect to the entire dataset. 
#------------------------------------------------------------------------------------
# Sample size is given as 20
# Stratified Sample
#------------------------------------------------------------------------------------
# Reference: Module 5 Pages 28,29,30,31(Unequal Strata)
#------------------------------------------------------------------------------------
# section.ids <- rep(LETTERS[1:4], c(10,20,30,40))
# section.scores <- round (runif(100, 60, 80))
#------------------------------------------------------------------------------------
order (df, MU284$REG)
section.ids <- 
  section.scores <- 
  #------------------------------------
data <- data.frame(
  Section = section.ids,
  Score = section.scores)
head(data)
freq <- table(data$Section)
freq
st.sizes <- 20*freq/sum(freq)
st.sizes
st.2 <- strata(data, stratanames=c("Section"), size=st.sizes,
               method="srswor", description=TRUE)
#------------------------------------------------------------------------------------
# e) Compare the means of RMT85 (revenues from 1985 municipal 
# taxation (in millions of kronor)) variable for these four samples 
# with the entire data.
#------------------------------------------------------------------------------------
# MU284$RMT85
# The four samples are:
s4a
s4b
s4c
y <- mean (MU284$RMT85)
plot (s4a,y)
plot (s4b,y)
plot (s4c,y)
#------------------------------------------------------------------------------------
# Sample size is given as 20
#------------------------------------------------------------------------------------
#
mean_rmt85 = mean ( MU284$RMT85 )
mean_entiredata
#------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------
# Run Plots
#------------------------------------------------------------------------------------
# Three plots arranged in 1 row:
#
par (mfrow=c(1,3))
#------------------------------------------------------------------------------------
hist (s4b, MU284$REG)
hist (s4b, MU284$S82)
#------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------ 
# Submission:  
# Create a folder, CS544_HW5_lastName and place the following files in this folder. 
# Create the RMarkdown file, CS544_HW5_lastName.Rmd, and provide all R
# code and corresponding outputs and explanations. 
# Knit the corresponding html file. 
# Archive the folder (CS544_HW5_lastName.zip). Upload the zip file to the
# Assignments section of Blackboard. 
#------------------------------------------------------------------------------------ 

