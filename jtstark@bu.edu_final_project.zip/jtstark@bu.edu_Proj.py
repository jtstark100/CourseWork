#----------------------------------------------
#----------------------------------------------
# File: jstark@bu.edu_Proj
#----------------------------------------------
# Term Project Assignment From: John Stark
# Course: MET CS 521
# Date: 10/20/2018
#----------------------------------------------
#----------------------------------------------
# Purpose:
#    The purpose of this project is as follows:
#    - To calculate and display bond details
#    - To calculate bond payment tables
#    - To use at least one Class and a variety of Python Data Types
#
# From Pythontutor.com:
#       - Server error! Your code might be too long for this tool. Shorten
#         your code and re-try. [#CodeTooLong] (See Note 1, Project Summary)
# References:
#	- CS 521 Homework Assigment: 5.3
# Attached Files:
#	- TermProjectSummary.txt
#	- AdditionalProjectCodeSnippets.txt
#	- SampleCSVFile.csv
#----------------------------------------------
#----------------------------------------------
#---------------------------------------------- Screen 1
import math
class Bond(object):
	# Construct a bond object
	def __init__(self, id, balance, annualInterestRate, numberOfPeriods, maturityDate, faceValue):
		self.__id__ = id		
		self.__balance__ = balance
		self.__annualInterestRate__ = annualInterestRate
		self.__numberOfPeriods__ = numberOfPeriods
		self.__maturityDate__ = maturityDate
		self.__faceValue__ = faceValue
#----------------------------- Accessing the Bond Object, basic inputs -- Screen 2
	def getId(self):
		return self.__id__
	def __str__(self):
		return '{} {}'.format('Bond: ', self.__id__)
	def getBalance(self):
		return self.__balance__
	def getAnnualInterestRate(self):
		return self.__annualInterestRate__
	def getNumberOfPeriods(self):
		return self.__numberOfPeriods__
	def getMaturityDate(self):
		return self.__maturityDate__
	def getfaceValue(self):
		return self.__faceValue__
#----------------------------- Accessing the Bond Object, per month -- Screen 3
	def getMonthlyInterestRate(self):
		return self.__annualInterestRate__ / 12
	def getMonthlyInterest (self):
		return ((self.__annualInterestRate__/12) * self.__faceValue__)
#----------------------------- Accessing the Bond Object, during setup -- Screen 4
	def setBalance(self, balance):
		# This is for setting up a Clients initial balance
		# during opening of account
		self.__balance__ = balance
		return
#--------------- Accessing the Bond Object, Service associated Clients Cash Account -- Screen 5
	def withdraw (self, wdraw):
		# This is for Client withdrawals
		self.__balance__ = self.balance - wdraw
		return
	def deposit(self, depos):
		# This is for Client deposits
		self.__balance__ = self.__balance__ + depos
		return
#----------------------------- End of Bond Object ------------------- Screen 6
def DisplayStartup (bondList):
	# Display bond list
	# Instantiate the bondList elements one bond at a time
	# and display its initial specifics at startup time
	for bond in ( bondList ):
		id = bond.getId()
		apr = bond.getAnnualInterestRate()
		nop = bond.getNumberOfPeriods()
		md = bond.getMaturityDate()
		fv = bond.getfaceValue()
		print ( "<Startup Summary>", id, apr, nop, md, fv )
	print("\n")
	return
def DisplayBondPayments (bondList, bondPaymentsList):
	# Display bond payments list, for all the bonds
	#Instantiate the bondList elements one at a time
	#
	for bond in ( bondList ):
		id = bond.getId()
		apr = bond.getAnnualInterestRate()
		nop = bond.getNumberOfPeriods()
		md = bond.getMaturityDate()
		fv = bond.getfaceValue()
		intr = fv * (apr/12)
		print("\n")
		paymentsList = ""
		for i in range ( 1, nop+1):
			paymentsList = paymentsList + "'self.i', intr, \
                        'bond.getMonthlyInterest'"
			print ("<Payment Summary>",i, id, apr, intr, nop, md, fv )

	print("\n")
	return
def printAccountSummary( bondList ):
	# Display the Client's cash account summary
	for bond in ( bondList ):
		id = bond.getId()
		bal = bond.getBalance()
		print ("<Client Cash Summary>",id, bal)
	print("\n")
	return
#-------------- Main -------------- -- Screen 7
# Instantiate the Bond objects
bond1 = Bond (1122, 20000, 0.045, 15, 2019, 10000.00)
bond2 = Bond (1123, 30000, 0.055, 10, 2019, 5000.00)
bond3 = Bond (1124, 20000, 0.065, 5, 2019, 10000.00)
bond4 = Bond (1125, 30000, 0.075, 2, 2019, 5000.00)
#
bondList = [] # Create a bond object list
bondList.append( bond1 )
bondList.append ( bond2 )
bondList.append( bond3 )
bondList.append ( bond4 )
# Display the initial state of the bond list
# Assume only one bond per Client
DisplayStartup (bondList)
#-------- Use the Bond List to generate principle/interest tables
paymentsList = [] # Create a payments list
# For each bond, display the payments schedule
DisplayBondPayments (bondList, paymentsList)
#-------------- End --------------








