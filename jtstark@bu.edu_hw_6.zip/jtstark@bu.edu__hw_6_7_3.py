
#----------------------------------------------
#
# Homework Assignment From: John Stark
# Course: MET CS 521
# Date: 10/14/2018
# Assignment: HW6 7.3 Page 237
#
# The Account Class
#
#----------------------------------------------
# Test Case: 
#----------------------------------------------
class Account(object):

	# Construct a rectangle object
	def __init__(self, id, balance, annualInterestRate):
		self.id = id		
		self.balance = balance
		self.annualInterestRate = annualInterestRate

	def getId(self):
		return self.id

	def getBalance(self):
		return self.balance

	def getAnnualInterestRate(self):
		return self.annualInterestRate

	def getMonthlyInterestRate(self):
		return self.annualInterestRate / 12

	def getMonthlyInterest (self):
		return ((self.annualInterestRate/12) * self.balance)

	def setId(self, id):
		self.id = id
		return

	def setBalance(self, balance):
		self.balance = balance
		return

	def setAnnualInterestRate(self, annualInterestRate):
		self.annualInterestRate = annualInterestRate
		return

	def withdraw (self, wdraw):
		self.balance = self.balance - wdraw
		return

	def deposit(self, depos):
		self.balance = self.balance + depos
		return

def printAccountSummary( acct ):
	id = acct.getId()
	balance = acct.getBalance()
	monthlyRate = acct.getMonthlyInterestRate()
	monthlyInterest = acct.getMonthlyInterest()
#
	print ("\n*********************")
	print ("Account Summary")
	print ("*********************")
#
	print("Id: ", id)
	print("Balance: ", balance)
	print("Monthly Rate: ", monthlyRate)
	print("Monthly Interest: ", monthlyInterest)
	return



#
# Instantiate the Account object
#
acct = Account(1122, 20000, 0.045)
#
printAccountSummary( acct )

acct.withdraw (2500)
printAccountSummary( acct )

acct.deposit (3000)
printAccountSummary( acct )



		