
#----------------------------------------------
#
# Homework Assignment From: John Stark
# Course: MET CS 521
# Date: 10/14/2018
# Assignment: HW6 12.1 Page 428
# (See Exercise 2.14, (Page59) formula to compute
# area of a triangle)
#
# The Triangle Class
#
#----------------------------------------------
# Extends Geometric Object
#----------------------------------------------
import math
class Triangle(object):

	# Construct a Triangle object
	def __init__(self, side1, side2, side3):
		self.side1 = 1.0		
		self.side2 = 1.0
		self.side3 = 1.0
		self.color = ""
		self.fill = 0

	def getSide1(self):
		return self.side1
	def getSide2(self):
		return self.side2
	def getSide3(self):
		return self.side3

	def setColor(self, color):
		self.color = color
		return
	def setFill(self, fill):
		self.fill = fill
		return

	def getArea(self):
		# See Exercise 2.14, (Page 59)
		s = (self.side1 + self.side2 + self.side3)/2
		area = math.sqrt (s*(s-self.side1)*(s-self.side2)*(s-self.side3))
		return area
	def getPerimeter(self):
		return self.side1 + self.side2 + self.side3

	def __str__():
		# String Description for the Triangle
		return "Triangle: side1 =" + str(side1) + \
                " side2 = " + str(side2) + "side3 = " + str(side3)

side1 = eval(input("Enter the length of the Triangle's sides (side1):  "))
side2 = eval(input("Enter the length of the Triangle's sides (side2):  "))
side3 = eval(input("Enter the length of the Triangle's sides (side3):  "))
#
triang = Triangle(side1, side2, side3)
#
color = input("Enter a color: ")
triang.setColor(color)
#
fill = input("Enter a fill: ")
triang.setFill(fill)








