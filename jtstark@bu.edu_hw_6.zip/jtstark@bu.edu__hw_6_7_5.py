
#----------------------------------------------
#
# Homework Assignment From: John Stark
# Course: MET CS 521
# Date: 10/14/2018
# Assignment: HW6 7.5 Page 237
#
# Geometry: n-sided regular polygon
#
#----------------------------------------------
import math
class RegularPolygon(object):

	# Construct a RegularPolygon object
	def __init__(self, n, side, x, y):
		self.n = 3	# Number of sides	
		self.side = 1.0	# Length of each side
		self.x = 0.0	# Center of Polygon
		self.y = 0.0	# Center of Polygon


	def getArea(self):
		return ( ( self.n * self.side ) / ( 4 * math.tan ( 3.14 / self.n) ) )

	def getPerimeter(self):
		return (self.n * self.side)

#
regPoly = RegularPolygon (6, 4, 0.0, 0.0)
print (regPoly.getArea())
print (regPoly.getPerimeter())
#
regPoly = RegularPolygon (10, 4, 5.6, 7.8)
print (regPoly.getArea())
print (regPoly.getPerimeter())
#
	