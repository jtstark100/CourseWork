
#----------------------------------------------
#
# Homework Assignment From: John Stark
# Course: MET CS 521
# Date: 10/14/2018
# Assignment: HW6 7.7 Page 238
# (See Exercise 4.3 for Sample Runs)
#
# Algebra: 2 x 2 Linear Equations
#
#----------------------------------------------
# Test Case: 9.0 4.0 3.0 -5.0 -6.0 -21.0
# Result: x = -2.0  and y = 3.0
#----------------------------------------------
# Test Case: 1.0 2.0 2.0 4.0 4.0 5.0
# Result: The equation has no solution
#----------------------------------------------
import math
class LinearEquation(object):

	# Construct a LinearEquation object
	def __init__(self, a, b, c, d, e, f):
		self.a = a		
		self.b = b
		self.c = c
		self.d = d
		self.e = e
		self.f = f

	def getA(self, a):
		return
	def getB(self, b):
		return
	def getC(self, c):
		return
	def getD(self, d):
		return
	def getE(self, e):
		return
	def getF(self, f):
		return

	# X & Y Return the solution to the equation
	#
	def getX(self):
		if (((self.a)*(self.d))-((self.b)*(self.c))):
			self.x =  (((self.e)*(self.d)) - ((self.b)*(self.f))) / (((self.a)*(self.d))-((self.b)*(self.c)))
		else:
			print ("\nThis equation has no solution")
			return 0.0
		return self.x
	def getY(self):
		if (((self.a)*(self.d))-((self.b)*(self.c))):
			self.y =  (((self.a)*(self.f)) - ((self.e)*(self.c))) / (((self.a)*(self.d))-((self.b)*(self.c)))
		else:
			print ("\nThis equation has no solution")
			return 0.0
		return self.y
#


# Returns True if ad - bc is not 0
#
def isSolvable(a,d, b, c):
	print ("\nisSolvable: a, d, b, c", a, d, b, c)
	return ((a)*(d))-((b)*(c))

inp = input ("Enter a b c d e f: " )
tokens = inp.split() #Extract tokens from the string
List1 = [eval(x) for x in tokens] # Convert tokens to numbers
length = len(List1)
print ( List1 )
print ( length )
#
a = List1[0]
b = List1[1]
c = List1[2]
d = List1[3]
e = List1[4]
f = List1[5]
#
print ("List1: ", List1)
linEq = LinearEquation (a, b, c, d, e, f)
print("X = ", linEq.getX())
print("Y = ", linEq.getY())
#
