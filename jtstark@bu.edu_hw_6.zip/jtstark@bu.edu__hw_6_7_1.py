
#----------------------------------------------
#
# Homework Assignment From: John Stark
# Course: MET CS 521
# Date: 10/14/2018
# Assignment: HW6 7.1 Page 237
#
# The Rectangle Class
#
#----------------------------------------------
# Test Cases: (w,h)(1,2)(4,40)(3.5,35.7)
#----------------------------------------------
class Rectangle(object):

	# Construct a rectangle object
	def __init__(self):
		self.width = 1		
		self.height = 2

	def getArea(self):
		return self.height * self.width

	def getPerimeter(self):
		return ((2*self.height) + (2*self.width))

	def setWidth(self, Width):
		self.width = Width
		return
		
	def setHeight(self, Height):
		self.height = Height
		return

#
rect = Rectangle()
#
width = 4
height = 40
rect.setWidth ( width )
rect.setHeight ( height )
print("Rect: ", rect.height, rect.width)
area = rect.getArea ()
perimeter = rect.getPerimeter()
print ("Width, Height, Area, Perimeter ", width, height, area, perimeter)
#
width = 3.5
height = 35.7
rect.setWidth ( width )
rect.setHeight ( height )
print("Rect: ", rect.height, rect.width)
area = rect.getArea ()
perimeter = rect.getPerimeter()
print ("Width, Height, Area, Perimeter ", width, height, area, perimeter)
#







		