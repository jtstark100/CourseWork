
#----------------------------------------------
#
# Homework Assignment From: John Stark
# Course: MET CS 521
# Date: 10/14/2018
# Assignment: HW6 12.3 Page 429
#
# Game: ATM Machine Simulator (See Prob 7.3)
#
#----------------------------------------------
class Account(object):

	# Construct a rectangle object
	def __init__(self, id, balance, annualInterestRate):
		self.id = id		
		self.balance = balance
		self.annualInterestRate = annualInterestRate

	def getId(self):
		return self.id

	def getBalance(self):
		return self.balance

	def getAnnualInterestRate(self):
		return self.annualInterestRate

	def getMonthlyInterestRate(self):
		return self.annualInterestRate / 12

	def getMonthlyInterest (self):
		return ((self.annualInterestRate/12) * self.balance)

	def setId(self, id):
		self.id = id
		return

	def setBalance(self, balance):
		self.balance = balance
		return

	def setAnnualInterestRate(self, annualInterestRate):
		self.annualInterestRate = annualInterestRate
		return

	def withdraw (self, wdraw):
		self.balance = self.balance - wdraw
		return

	def deposit(self, depos):
		self.balance = self.balance + depos
		return

def printAccountSummary( acct ):
	id = acct.getId()
	balance = acct.getBalance()
	monthlyRate = acct.getMonthlyInterestRate()
	monthlyInterest = acct.getMonthlyInterest()
#
	print ("\n*********************")
	print ("Account Summary")
	print ("*********************")
#
	print("Id: ", id)
	print("Balance: ", balance)
	print("Monthly Rate: ", monthlyRate)
	print("Monthly Interest: ", monthlyInterest)
	return

# Print an Account Summary for a specific account
#
def nprintAccountSummary( n, acct ):
	id = n
	balance = acct.getBalance()
	monthlyRate = acct.getMonthlyInterestRate()
	monthlyInterest = acct.getMonthlyInterest()
#
	print ("\n*********************")
	print ("Account Summary")
	print ("*********************")
#
	print("Id: ", id)
	print("Balance: ", balance)
	print("Monthly Rate: ", monthlyRate)
	print("Monthly Interest: ", monthlyInterest)
	return


# Create a list of new accounts
#
def createAccountList ():

	# Establish ten new account objects in a list
	# with an initial balance of $100
	#
	acct0 = Account(0, 100, 0.045)
	acct1 = Account(1, 100, 0.045)
	acct2 = Account(2, 100, 0.045)
	acct3 = Account(3, 100, 0.045)
	acct4 = Account(4, 100, 0.045)
	acct5 = Account(5, 100, 0.045)
	acct6 = Account(6, 100, 0.045)
	acct7 = Account(7, 100, 0.045)
	acct8 = Account(8, 100, 0.045)
	acct9 = Account(9, 100, 0.045)
	#
	acct = []
	acct.append(acct0)
	acct.append(acct1)
	acct.append(acct2)
	acct.append(acct3)
	acct.append(acct4)
	acct.append(acct5)
	acct.append(acct6)
	acct.append(acct7)
	acct.append(acct8)
	acct.append(acct9)
	#print ("acct: ", acct)
	return acct


# Run the Main Menu
#
def mainMenu ():
	acct = createAccountList ()
	#print ("acct: ", acct)
	n = int (input ("\nEnter an account id (0-9): "))
	while (1):
		print ("\n\nMain Menu\n")
		print ("1: check balance")
		print ("2: withdraw")
		print ("3: deposit")
		print ("4: exit")
		#
		choice = int ( input ("\nEnter a choice (1-4): "))
		print ("choice: ", choice)
		if (choice == 1):
			# Check Balance
			print ("The balance is: ", acct[n].getBalance())
		else:
			if (choice == 2):
				# Withdrawal
				wDrawal = eval ( input ("\nEnter Withdrawal: "))
				newBalance = acct[n].getBalance() - wDrawal
				acct[n].setBalance(newBalance)
			else:
				if (choice == 3):
					# Deposit
					dPosit = eval (input ("\nEnter Deposit Amount: "))
					newBalance = acct[n].getBalance() + dPosit
					acct[n].setBalance(newBalance)
				else:
					if (choice == 4):
						# exit
						break
		#print ("The balance is: ", acct[n].getBalance())
	return


#main


# Run the Main Menu with the account objects
#
mainMenu ()
exit

