#***********************************************************
# John Stark
# MET CS 555 - Data Visualization
# April 21, 2020
#
#***********************************************************
# Assignment 6
#***********************************************************
#                                                  
# SUBMISSION REQUIREMENTS: 
#
# Please submit a single document (word or PDF) for submission.
# Your submission should contain a summary of your results
# (and answers to questions asked on the homework) as well as
# your R code used to generate your results (please append
# to the end of your submission).
#
# References:
#
# 1) R Cookbook
#      by JD Long and Paul Teetor
#      O'Reilly - Second Editon
#
# 2) R Graphics Cookbook
#      by Winston Chang
#      O'Reilly - Second Editon
#
# 3)  YT: Two Sample t-Test in R... | R Tutorial 4.2
#      MarinStatsLectures Channel
#
# 4) YT: Confidence Interval Concept Explained
#      Statistics Tutorial #7
#       MarinStatsLectures
#
#***********************************************************
#
# Reference Module 6 Example 3
# (One time installations):
# install.packages("aod")
# install.packages("pROC")
#
# The downloaded binary packages are in
#  C:\Users\jstark\AppData\Local\Temp\Rtmp6F3wm4\downloaded_packages
#
#***********************************************************
# CS555 Module 6 Assignment 
#***********************************************************
#pdf("JTS_hw6_rplot.pdf") 
#*****************************************************************************************

#********** BEGIN DATA LOADING, SETUP CHECK, CLEANUP AND CHECKING ************

#**********************************************************************************************
# The data in this document consists of body temperature measurements and
# heart rate measurements for 65 men and 65 women.  Save the data to excel
# and read the data into R.  Use this data to address the following questions.
#**********************************************************************************************

#**********************************************************************************************
# Save the data to excel or CSV file and read into R for analysis.
#**********************************************************************************************
# Let us remove all variables from the memory to have nothing in memory 
rm(list=ls())
#
setwd("C:/Users/jstark/Desktop/MET_CS_555/HW6")
getwd()
df1 = read.csv ("./Datasets/hw6_data.csv")
head (df1)
tail (df1)
length (temp)
length (sex)
length (rate)
attach(df1)

#********** END OF DATA LOADING, SETUP CHECK, CLEANUP AND CHECKING ************

#**********************************************************************************************
# (1) We are interested in whether the proportion of men and women with body 
# temperatures greater than or equal to 98.6 degrees Fahrenheit are equal. 
# Therefore, we need to dichotomize the body temperature variable. 
# Create a new variable, called "temp_level" in which temp_level = 1 if body 
# temperature >= 98.6 and temp_level=0 if body temperature < 98.6. (1 point)
#**********************************************************************************************
df1$temp_level <- ifelse (temp>=98.6,1, 0)
df1
length (df1$temp_level)

#********** END OF (1) **********************************************************************

#**********************************************************************************************
# (2) Summarize the data relating to body temperature level by sex. (2 points)
#**********************************************************************************************
males <- subset (df1, sex=="1")
males
summary (males)
#
#      temp            sex         rate         temp_level    
# Min.   :96.30   Min.   :1   Min.   :58.00   Min.   :0.0000  
# 1st Qu.:97.50   1st Qu.:1   1st Qu.:69.00   1st Qu.:0.0000  
# Median :98.00   Median :1   Median :72.00   Median :0.0000  
# Mean   :97.99   Mean   :1   Mean   :72.91   Mean   :0.2154  
# 3rd Qu.:98.40   3rd Qu.:1   3rd Qu.:78.00   3rd Qu.:0.0000  
# Max.   :99.50   Max.   :1   Max.   :87.00   Max.   :1.0000 
#
females <- subset (df1, sex=="2")
females
summary (females)
#     temp             sex         rate         temp_level    
# Min.   : 96.40   Min.   :2   Min.   :57.00   Min.   :0.0000  
# 1st Qu.: 98.20   1st Qu.:2   1st Qu.:69.00   1st Qu.:0.0000  #
# Median : 98.60   Median :2   Median :77.00   Median :1.0000  
# Mean   : 98.51   Mean   :2   Mean   :74.62   Mean   :0.5385  
# 3rd Qu.: 98.80   3rd Qu.:2   3rd Qu.:79.00   3rd Qu.:1.0000  
# Max.   :100.80   Max.   :2   Max.   :89.00   Max.   :1.0000  
#

#********** END OF (2) **********************************************************************

#**********************************************************************************************
# (3) Calculate the risk difference.  Formally test (at the alpha =.05 level) whether the
# proportion of people with higher body temperatures (greater than or equal to 98.6)
# is the same across men and women, based on this effect measure.  
# Do females have higher body temperatures than males? (4.5 points)
#**********************************************************************************************
#
# Calculate the Risk Difference:
#    risk difference = phat1-phat2
#
#  As shown in the summaries above, females have a mean temperature of 98.51,
#  and males have a mean temperation of 97.99
#
# Formally Test:
#
# Whether the  proportion(temp_level) of people with higher body temperatures 
# (greater than or equal to 98.6) is the same across men and women, based
# on this effect measure.
#
# Five Step Test:
# Testing Proportions with prop.test
#
# 1) Setup Hypothesis and significance:
#
# H0 : mu (females) = mu (males)
# H1:  mu (females) NOT = mu (males)
# alpha =0.05
# (two sided)
#
# 2) Select a t test statistic:
#
# Lecture Notes Page 20:
# (temp_level)
t.test (males$temp, females$temp, paired = TRUE, 
        alternative="two.sided", conf.level=0.95)
# Paired t-test
# data:  males$temp and females$temp
# t = -5.2974, df = 64, p-value = 1.543e-06
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
# -0.7160991 -0.3239009
# sample estimates:
# mean of the differences 
#                  -0.52 
#
# 3) State the decision rule:
#
#      abs( t) >= 1.96
#      t = -5.2974
#
# We have significant evidence at the alpha = 0.05 level, that mu(males) does
# not equal mu(females)
#
# 4) Compute the test statistic and the associated p-value
#
# t = -5.2974, df = 64, p-value = 1.543e-06
# alternative hypothesis: true difference in means is not equal to 0
#
# 5) State Conclusions
#
# Reject H0 because p-value is low
#
#
# Do females have higher body temperatures than males?
#
# No, H0 is rejected because females and males do not have the same mean.
# The female mean is calculated as: 98.51
# The male mean is calculated as: 97.99
#
#********** END OF (3) **********************************************************************

#**********************************************************************************************
# (4) Perform a logistic regression with sex as the only explanatory variable.  
# Formally test (at the alpha=.05 level) if the odds of having a temperature greater than
# or equal to 98.6 is the same between males and females.   Include the odds 
# ratio for sex and the associated 95% confidence interval based on the model 
# in your summary and interpret this value.  What is the c-statistic for this model?
# (5.5 points)
#**********************************************************************************************
#
# Perform a logistic regression with sex as the only explanatory variable.
#
m <- glm(df1$temp_level ~ df1$sex, family = "binomial")
m
summary(m)
#--------------------------------------------------------------------------------------------
# Call:  glm(formula = df1$temp_level ~ df1$sex, family = "binomial")
# Coefficients:
# (Intercept)      df1$sex  
#     -2.740        1.447  
# Degrees of Freedom: 129 Total (i.e. Null);  128 Residual
# Null Deviance:	    172.3 
# Residual Deviance: 157.5 	AIC: 161.5
#--------------------------------------------------------------------------------------------
# Call:
# glm(formula = df1$temp_level ~ df1$sex, family = "binomial")
# Deviance Residuals: 
#    Min       1Q   Median       3Q      Max  
# -1.2435  -0.6965  -0.6965   1.1127   1.7523  
# Coefficients:
#            Estimate Std. Error z value Pr(>|z|)    
# (Intercept)  -2.7397     0.6527  -4.197  2.7e-05 ***
# df1$sex       1.4469     0.3911   3.700 0.000216 ***
# ---
# Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# (Dispersion parameter for binomial family taken to be 1)
#    Null deviance: 172.26  on 129  degrees of freedom
# Residual deviance: 157.45  on 128  degrees of freedom
# AIC: 161.45
# Number of Fisher Scoring iterations: 4
#--------------------------------------------------------------------------------------------
# Formally test (at the alpha=0.05 level) if the odds of having a temperature greater than
# or equal to 98.6 is the same between males and females
#--------------------------------------------------------------------------------------------
#
# Five Step Test:
# Reference Module 6 Example 3
# Testing Proportions, prop.test
#
# 1) Setup Hypothesis and significance:
#
# H0 : femaleodds = maleodds
# H1:  femaleodds NOT= maleodds
# alpha =0.05
# (two-sided)
#
# 2) Select a test statistic:
#
# The p-value has been calculated by the glm:
# df1$sex       1.4469     0.3911   3.700 0.000216 ***
#
# 3) State the decision rule:

# H0 should be rejected because the p value is low:
# df1$sex       1.4469     0.3911   3.700 0.000216 ***
#
# 4) Compute the test statistic and the associated p-value
# df1$sex       1.4469     0.3911   3.700 0.000216 ***
#
# 5) State Conclusions
# Reject H0 because we have significant evidence at the alpha = 0.05 level that
# that female odds do not equal male odds.
#
# Include the odds (of the outcome) ratio for sex  and the associated 95% confidence
# interval based on the model in your summary and interpret this value:

# The 95% confidence interval is mu +/- 2 * (standard deviation around the mean)

#     An estimate of the odds ratio is: ((phat1)/(1-phat1)) / ((phat2)/(1-phat2))
#
# What is the c-statistic for this model?

#     The c-statistic is the area under the ROC curve.
#

#********** END OF (4) **********************************************************************

#**********************************************************************************************
# (5) Perform a multiple logistic regression predicting body temperature level
# from sex and heart rate.  Summarize briefly the output from this model.  
# Give the odds ratio for sex and heart rate (for a 10 beat increase).  
# What is the c-statistic of this model?  (5 points)
#**********************************************************************************************
#-----------------------------------------------------------------------------------------------------------
# (For the case of a Logistic Regression the Area under the ROC Curve (c-statistic) is 
# a measure of the goodness of fit)
#-----------------------------------------------------------------------------------------------------------
# Perform a multiple logistic regression with sex and heart rate as explanatory variables
# (Predicting body temperature level)
#

m2 <- glm(df1$temp_level ~ df1$sex + df1$rate, family = "binomial")
m2
# Call:  glm(formula = df1$temp_level ~ df1$sex + df1$rate, family = "binomial")
# Coefficients:
# (Intercept)      df1$sex     df1$rate  
#   -7.34755      1.38919      0.06337  
# Degrees of Freedom: 129 Total (i.e. Null);  127 Residual
# Null Deviance:	    172.3 
# Residual Deviance: 152.2 	AIC: 158.2

summary(m2)
# Call:
# glm(formula = df1$temp_level ~ df1$sex + df1$rate, family = "binomial")
# Deviance Residuals: 
#    Min       1Q   Median       3Q      Max  
# -1.6524  -0.8639  -0.6103   1.0489   2.0480  
# Coefficients:
#            Estimate Std. Error z value Pr(>|z|)    
# (Intercept) -7.34755    2.21406  -3.319 0.000905 ***
# df1$sex      1.38919    0.39868   3.484 0.000493 ***
# df1$rate     0.06337    0.02850   2.223 0.026195 *  
# ---
# Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# (Dispersion parameter for binomial family taken to be 1)
#    Null deviance: 172.26  on 129  degrees of freedom
# Residual deviance: 152.24  on 127  degrees of freedom
# AIC: 158.24
# Number of Fisher Scoring iterations: 4
#
# Estimate of odds ratio:
# Odds Ratio = (phat1 / (1-phat1)) / (phat2/1-phat2))
#

#********** END OF (5) **********************************************************************

#**********************************************************************************************
# (6) Which model fit the data better?  Support your response with evidence from
# your output.  Present the ROC curve for the model you choose. (2 points)
#**********************************************************************************************
#
# Which model fits the data better?:
# Support your response with evidence from your output:
#
# The sex and heart rate model is the best because Null Deviance, Residual Deviance and 
#  and A/C are all smaller. (152.2, 158.2). Null Deviance (172.3) is only slightly larger.
# Refer to "Goodnes of Fit" and plot section below.
#

#  This compares with the sex only model which had (172.26, 157.5, 161.5).
# (For the case of a Logistic Regression the Area under the ROC Curve (c-statistic) is 
# a measure of the goodness of fit).  In this case the area under the curve is 0.7289
# which is a reasonably good fit.
#
# Present the ROC curve for the model you choose:
#   Refer to attached plot
#
# Adapted from Page 49 Lecture 12 Notes:

# Reference: Module 6 Example 3

m2 <- glm(df1$temp_level ~ df1$sex + df1$rate, family = "binomial")
m2
# Call:  glm(formula = df1$temp_level ~ df1$sex + df1$rate, family = "binomial")
# Coefficients:
#  (Intercept)      df1$sex     df1$rate  
# -7.34755      1.38919      0.06337  
# Degrees of Freedom: 129 Total (i.e. Null);  127 Residual
# Null Deviance:	    172.3 
# Residual Deviance: 152.2 	AIC: 158.2

summary (m2)
# Call:
#  glm(formula = df1$temp_level ~ df1$sex + df1$rate, family = "binomial")
# Deviance Residuals: 
#  Min       1Q   Median       3Q      Max  
# -1.6524  -0.8639  -0.6103   1.0489   2.0480  
# Coefficients:
#  Estimate Std. Error z value Pr(>|z|)    
# (Intercept) -7.34755    2.21406  -3.319 0.000905 ***
#  df1$sex      1.38919    0.39868   3.484 0.000493 ***
#  df1$rate     0.06337    0.02850   2.223 0.026195 *  
#  ---
# Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# (Dispersion parameter for binomial family taken to be 1)
# Null deviance: 172.26  on 129  degrees of freedom
# Residual deviance: 152.24  on 127  degrees of freedom
# AIC: 158.24
# Number of Fisher Scoring iterations: 4

# ORs per 1 unit increase
exp (cbind (OR = coef(m2), confint.default (m2)))
#                        OR        2.5 %     97.5 %
#  (Intercept) 0.0006441665 8.402017e-06 0.04938701
# df1$sex     4.0115853304 1.836365e+00 8.76340901
# df1$rate    1.0654181538 1.007534e+00 1.12662800

#ROC curve 
# install.package ("pROC")
library (pROC)

#using model with 
df1$prob <- predict(m2, type=c("response"))

# Build a ROC curve
g <- roc(df1$temp_level ~ df1$prob )
# Setting levels: control = 0, case = 1
# Setting direction: controls < cases

# See the results - c-statistics value
print (g)
# Call:
#  roc.formula(formula = df1$temp_level ~ df1$prob)
# Data: df1$prob in 81 controls (df1$temp_level 0) < 49 cases (df1$temp_level 1).
# Area under the curve: 0.7289
#-----------------------------------------------------------------------------------------------------------
# Goodness of fit:
#-----------------------------------------------------------------------------------------------------------
# (For the case of a Logistic Regression the Area under the ROC Curve (c-statistic) is 
# a measure of the goodness of fit)
#-----------------------------------------------------------------------------------------------------------
# plot the ROC curve
plot (g)

#********** END OF (6) **********************************************************************

warnings()
# Warning message:
#**********************************************************************************************
# Stop Plotting to .pdf
#dev.off()
#**********************************************************************************************

