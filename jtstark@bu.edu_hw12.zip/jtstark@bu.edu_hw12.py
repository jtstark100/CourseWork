# -*- coding: utf-8 -*-
"""
Created on Wed Apr 17 13:38:43 2019

@author: epinsky
"""

#****************************************************
# jtstark@bu.edu_hw12.py
#****************************************************
#
# Modified by: John Stark
# MET CS 677 - April 21, 2019
# Assignment HW12
#
#****************************************************
# Summary: 
#*****************************************************
# HW12
#*****************************************************
# use k-means to cluster your weeks and see the composition
#  of the clusters
#
# First Assignment:
#
# 1. You have a labeled data set (2017 + 2018)
#   Take (x1,y1), 

(x104, y104)  - 2 years of data and cluster
#
# Task 1:    Use sklearn library , take 5 clusters and plot
#           the results
#           (random initial condition, use the defaults
.)
# 
# Task 2: for the same dataset, find out the best k   
# k = [1,2, 3,4,5,6,7,8]. Plot the distortion vs k
# and find out the best k
#
# Task 3: for this optimal k, examine your clusters:
# Cluster #      % red  weeks    % green labels
# 1                              30         70
# 2                              95          5
#
# Task 4:  implement k-means (assignment and update)
#  for Euclidean, street and Minkowski distance
#
#*****************************************************
# References:
#    1) http://www.sci-learn.org/
#    2) https://scikit-learn.org/stable/modules/svm.html
#       https://scikit-learn.org/stable/modules/generated/sklearn.svm.LinearSVC.html
#       https://pythonprogramming.net/linear-svc-example-scikit-learn-svm-python/
#    3) Machine Learning Tutorial with Python (7) 
#       Training and Testing - Youtube Channel: codebasics
#
# http://benalexkeen.com/k-means-clustering-in-python/
# https://bigdatascienc.wordpress.com/2017/12/29/k-means-clustering-in-python/
#
# KMeans Elbow Method:
# https://pythonprogramminglanguage.com/kmeans-elbow-method/
#
#*****************************************************
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
#%matplotlib inline

#df = pd.DataFrame({
#    'x': [12, 20, 28, 18, 29, 33, 24, 45, 45, 52, 51, 52, 55, 53, 55, 61, 64, 69, 72],
#    'y': [39, 36, 30, 52, 54, 46, 55, 59, 63, 70, 66, 63, 58, 23, 14, 8, 19, 7, 24]
#})

#*************************************************
# File Open
#*************************************************
import os
input_dir = r'C:\Users\jstark\bu\python\data_science_with_Python\datasets'
#---------------------------
# x=>  Volatility
# y => mean_return
#---------------------------
input_file = os.path.join(input_dir, 'SO8_weekly_return_volatility1.csv')
df = pd.read_csv(input_file)
print (df.head())
#---------------------------
np.random.seed(200)
k = 3
# centroids[i] = [x, y]
centroids = {
    i+1: [np.random.randint(0, 80), np.random.randint(0, 80)]
    for i in range(k)
}
print (centroids)
 #--------------------------- 
fig = plt.figure(figsize=(5, 5))
plt.scatter(df['x'], df['y'], color='k')
# Red, green, and blue colors
colmap = {1: 'r', 2: 'g', 3: 'b'}
for i in centroids.keys():
    plt.scatter(*centroids[i], color=colmap[i])
plt.title('Random Centroids')
plt.xlim(-2, 2)
plt.ylim(-2, 2)
plt.show()
#----------------------------------------------------------------
# Assignment and Update are repeated until convergence
#----------------------------------------------------------------
# assignment stage
# Assigns each input data to a centroid
def assignment(df, centroids):
    for i in centroids.keys():
        # sqrt((x1 - x2)^2 - (y1 - y2)^2)
        df['distance_from_{}'.format(i)] = (
            np.sqrt(
                (df['x'] - centroids[i][0]) ** 2
                + (df['y'] - centroids[i][1]) ** 2
            )
        )
    centroid_distance_cols = ['distance_from_{}'.format(i) for i in centroids.keys()]
    df['closest'] = df.loc[:, centroid_distance_cols].idxmin(axis=1)
    df['closest'] = df['closest'].map(lambda x: int(x.lstrip('distance_from_')))
    df['color'] = df['closest'].map(lambda x: colmap[x])
    return df
#----------------------------------------------------------------
df = assignment(df, centroids)
print ('Assignment:')
print(df.head())
#
fig = plt.figure(figsize=(5, 5))
plt.scatter(df['x'], df['y'], color=df['color'], alpha=0.5, edgecolor='k')
for i in centroids.keys():
    plt.scatter(*centroids[i], color=colmap[i])
plt.title('Initial Assignment')
plt.xlim(-2, 2)
plt.ylim(-2, 2)
plt.show()
#---------------------------
# update stage

import copy

old_centroids = copy.deepcopy(centroids)
#----------------------------------------------------------------
#  Assignment and Update are repeated until convergence
#----------------------------------------------------------------
def update(k):
    for i in centroids.keys():
        centroids[i][0] = np.mean(df[df['closest'] == i]['x'])
        centroids[i][1] = np.mean(df[df['closest'] == i]['y'])
    return k
#----------------------------------------------------------------

centroids = update(centroids)
print ('Centroids Updated: ', centroids)
print ('Centroids.keys(): ', centroids.keys())
    
fig = plt.figure(figsize=(5, 5))
ax = plt.axes()
plt.scatter(df['x'], df['y'], color=df['color'], alpha=0.5, edgecolor='k')
for i in centroids.keys():
    plt.scatter(*centroids[i], color=colmap[i])
plt.xlim(-2, 2)
plt.ylim(-2, 2)
for i in old_centroids.keys():
    old_x = old_centroids[i][0]
    old_y = old_centroids[i][1]
    dx = (centroids[i][0] - old_centroids[i][0]) * 0.75
    dy = (centroids[i][1] - old_centroids[i][1]) * 0.75
    ax.arrow(old_x, old_y, dx, dy, head_width=2, head_length=3, fc=colmap[i], ec=colmap[i])
plt.title('Updated Assignment')
plt.show()
#---------------------------
# repeat assignment stage

df = assignment(df, centroids)

# Plot results
fig = plt.figure(figsize=(5, 5))
plt.scatter(df['x'], df['y'], color=df['color'], alpha=0.5, edgecolor='k')
for i in centroids.keys():
    plt.scatter(*centroids[i], color=colmap[i])
plt.title ('Repeat Assignment')
plt.xlim(-2, 2)
plt.ylim(-2, 2)
plt.show()
#---------------------------
# run additional iterations
#----------------------------------------------------------------
# Assignment and Update are repeated until convergence
#----------------------------------------------------------------
# Continue until all assigned categories don't change any more
#----------------------------------------------------------------
while True:
    print ('Assignment and Update are repeated until convergence')
    closest_centroids = df['closest'].copy(deep=True)
    centroids = update(centroids)    #**** UPDATE ****
    df = assignment(df, centroids)   #**** ASSIGNMENT ****
    if closest_centroids.equals(df['closest']):
        break
#----------------------------------------------------------------
print ('CONVERGENCE: ', centroids)
fig = plt.figure(figsize=(5, 5))
plt.scatter(df['x'], df['y'], color=df['color'], alpha=0.5, edgecolor='k')
for i in centroids.keys():
    plt.scatter(*centroids[i], color=colmap[i])
plt.title ('After Additional Iterations')
plt.xlim(-2, 2)
plt.ylim(-2, 2)
plt.show()

# same thing using sklearn:

#df = pd.DataFrame({
#    'x': [12, 20, 28, 18, 29, 33, 24, 45, 45, 52, 51, 52, 55, 53, 55, 61, 64, 69, 72],
#    'y': [39, 36, 30, 52, 54, 46, 55, 59, 63, 70, 66, 63, 58, 23, 14, 8, 19, 7, 24]
#})

#**************************************************************

print ('Same thing using sklearn:')
print (df.head())

from sklearn.cluster import KMeans

print ('Entering KMeans.fit with:')
df.head()
#-------------------------------------------------------------------
# Task 1: Use sklearn library, take 5 clusters and plot the results
#-------------------------------------------------------------------
kmeans = KMeans(n_clusters=5)
print ('Create the Model:')
# kmeans.fit(df)

print ('Use the Model to predict:')
labels = kmeans.predict(df)
centroids = kmeans.cluster_centers_

colors = map(lambda x: colmap[x+1], labels)
#colors=['green', 'red', 'blue']


plt.scatter(df['x'], df['y'], color=colors, alpha=0.5, edgecolor='k')
#*********************************************************************
# ValueError: 'c' argument has 3 elements, which is not acceptable
# for use with 'x' with size 19, 'y' with size 19.
#*********************************************************************
for idx, centroid in enumerate(centroids):
    plt.scatter(*centroid, color=colmap[idx+1])
plt.title ('Same Result with Sklearn')
plt.xlim(-2, 2)
plt.ylim(-2, 2)
plt.show()
#-------------------------------------------------------------------
# Task 2: Find out the best k, k=[1,2,3,4,5,6,7,8]
#         Plot the distortion and find out the best k
#-------------------------------------------------------------------
#*****************************************************************
# Reference:
# https://pythonprogramminglanguage.com/kmeans-elbow-method/
#*****************************************************************

# clustering dataset
# determine k using elbow method

from sklearn.cluster import KMeans
#from sklearn import metrics
from scipy.spatial.distance import cdist
import numpy as np
import matplotlib.pyplot as plt

#x1 = np.array([3, 1, 1, 2, 1, 6, 6, 6, 5, 6, 7, 8, 9, 8, 9, 9, 8])
#x2 = np.array([5, 4, 5, 6, 5, 8, 6, 7, 6, 7, 1, 2, 1, 2, 3, 2, 3])

plt.plot()
plt.xlim([-2, 2])
plt.ylim([-2, 2])
plt.title('Dataset')
plt.scatter(df['x'], df['y'])
plt.show()

# create new plot and data
plt.plot()
X = np.array(list(zip(df['x'], df['y']))).reshape(len(df['x']), 2)
colors = ['b', 'g', 'r']
markers = ['o', 'v', 's']

# k means determine k
distortions = []
K = range(1,10)
for k in K:
    kmeanModel = KMeans(n_clusters=k).fit(X)
    kmeanModel.fit(X)
    distortions.append(sum(np.min(cdist(X, kmeanModel.cluster_centers_, 'euclidean'), axis=1)) / X.shape[0])

# Plot the elbow
plt.plot(K, distortions, 'bx-')
plt.xlabel('k')
plt.ylabel('Distortion')
plt.title('The Elbow Method showing the optimal k')
plt.show()

df.head()

#-------------------------------------------------------------------
# Task 3: For this optimal k, examine your clusters:
# Cluster #     %Red weeks     %Green labels
#-------------------------------------------------------------------


#-------------------------------------------------------------------
# Task 4: Implement k-means assignment and update for Euclidean, 
#         street, and Minkowski distance
#-------------------------------------------------------------------

# Reference:
# https://scikit-learn.org/stable/modules/
# generated/sklearn.neighbors.DistanceMetric.html




